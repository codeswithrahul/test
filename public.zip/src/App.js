import logo from "./logo.svg";
import "./App.css";
import { Outlet, useLocation, useNavigate } from "react-router";
import { componentsName } from "./component/utils/utils";
import Navbar from "./component/Reusable/Navbar";

function App() {
  const Navigate = useNavigate();
  const location = useLocation();

  console.log(location, "location");

  return (
    <div className="App">
      <Navbar />
      {location.pathname === "/" && (
        <div>
          <div className="hero-section">
            <h3>
              Welcome to <span className="frontend-text">Frontend </span>
              Adventure
            </h3>
            <p className="tech-stack">
              <span className="react-text"> React</span> &middot;
              <span className="css-text"> javascript </span>  &middot;
              <span className="javascript-text"> CSS </span> 
            </p>
          </div>

          <p></p>
          <div className="project-navigate-container">
            {componentsName.map(({ name, routePath }) => (
              <button className="btn">{name}</button>
            ))}
          </div>
        </div>
      )}
      <Outlet />
    </div>
  );
}

export default App;
