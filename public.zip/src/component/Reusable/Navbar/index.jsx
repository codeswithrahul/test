import React from "react";
import reactLogo from "../../../assest/images/logo.png";
import GitHubIcon from "@mui/icons-material/GitHub";
import "./navbar.css";

const Navbar = () => {
  return (
    <nav>
      <div className="logo">
        <img src={reactLogo} alt="react-logo" className="nav-logo" />
        <div></div>
        <h1> <span className="react">Frontend </span>Adventure</h1>
      </div>
      <div className="flex-center">
        <GitHubIcon />
        <h4>codeswithrahul</h4>
      </div>
    </nav>
  );
};

export default Navbar;
