import React from 'react'

const Accordion = () => {
  return (
    <div>Accordion</div>
  )
}

export default Accordion